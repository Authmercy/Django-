from django.urls import path
from .views import *

urlpatterns = [
      
    path('adminsign_up/', AdminSign_Up, name='adminsign_up'),
    path('adminsign_in/', AdminSign_In, name='adminsign_in'),
     path('admin_login/', Login, name='login'),
  path('logout',logout_form, name='logout'),
]