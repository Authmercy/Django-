
# Create your views here.
from django.shortcuts import render, redirect
from django.core.validators import validate_email
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout

# Create your views here.


def AdminSign_Up(request):
    
    error = False
    message = ""
    if request.method == "POST":
        adminname = request.POST.get('adminname', None)
        adminemail = request.POST.get('adminemail', None)
        adminpassword = request.POST.get('adminpassword', None)
        adminrepassword = request.POST.get('adminrepassword', None)
        # Email
        try:
            validate_email(adminemail)
        except:
            error = True
            message = "Enter un email valide svp!"
        # password
        if error == False:
            if adminpassword != adminrepassword:
                error = True
                message = "Les deux mot de passe ne correspondent pas!"
        # Exist
        user = User.objects.filter(Q(email=adminemail) | Q(username=adminname)).first()
        if user:
            error = True
            message = f"Un utilisateur avec email {adminemail} ou le nom d'utilisateur {adminname} exist déjà'!"
        
        # register
        if error == False:
            user = User(
                username = adminname,
                email = adminemail,
            )
            user.save()

            user.adminpassword = adminpassword
            user.set_password(user.adminpassword)
            user.save()

            return redirect('adminsign_in')

            #print("=="*5, " NEW POST: ",name,email, password, repassword, "=="*5)

    context = {
        'error':error,
        'message':message
    }
  
    return render(request,'adminregister.html', context)

def AdminSign_In(request):

   if request.method == "POST":
        email = request.POST.get('email', None)
        password = request.POST.get('password', None)

        user = User.objects.filter(email=email).first()
        if user:
            auth_user = authenticate(username=user.username,password=password)
            if auth_user:
                login(request, auth_user)
                return redirect('index')
            else:
                print("mot de pass incorrecte")
        else:
            print("User does not exist")

   return render(request, 'adminlogin.html', {})
 
def Login(request):
    error = ""
    if request.method =="POST":
        u = request.POST['adminuname']
        p = request.POST['adminpwd']
        user = authenticate(username=u, password=p)
        try:
            if user.is_staff:
                login(request, user)
                error = "no"
                
            else:
                error = "yes"
                
        except:
           error = "yes"
    d = {'error': error}
    return render(request, 'login1.html', d)

def logout_form(request):
    logout(request)
    return redirect('home')
