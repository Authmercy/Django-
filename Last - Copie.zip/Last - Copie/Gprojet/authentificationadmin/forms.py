from django import forms

class LoginForm(forms.Form):
    adminemail = forms.CharField(label="email",widget=forms.TextInput(attrs={'class': 'form-control'}))
    adminpwd = forms.CharField(label = "mot de passe", widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    
class RegisterForm(forms.Form):
    adminusername = forms.CharField(label="nom utilisateur",widget=forms.TextInput(attrs={'class': 'form-control'}))
    adminemail = forms.EmailField(label="E-mail",widget=forms.TextInput(attrs={'class': 'form-control'}))
    adminpwd = forms.CharField(label = "mot de passe", widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    adminpwd_confirm = forms.CharField(label = "mot de passe de confirmation", widget=forms.PasswordInput(attrs={'class': 'form-control'}))