from django.urls import path
from .views import *

urlpatterns = [
    path('user', User, name='user'),
    path('sign_up/', Sign_Up, name='sign_up'),
    path('sign_in/', Sign_In, name='sign_in'),
    path('admin_login/', Login, name='login'),
  path('logout',logout_form, name='logout'),
]