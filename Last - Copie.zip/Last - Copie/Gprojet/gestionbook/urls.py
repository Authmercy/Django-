from django import urls
from django.urls import path, re_path
from . import views
from Gprojet.settings import DEBUG, STATIC_ROOT,STATIC_URL,MEDIA_ROOT,MEDIA_URL

from django.views.static import serve
from .views import *
from . import views 
from django.conf.urls.static import static

urlpatterns = [
    path('', views.home, name='home'),
       path('search/', views.search, name='search'),
         path('searchcat/', views.searchcat, name='searchcat'),
       path('searchadmin/', views.searchadmin, name='searchadmin'),
    path('add', views.ADD, name='add'),
    path('index', views.index, name='index'),
    path('author', views.author, name='author'),
   path('document', views.document, name='document'),
      path('adddoc', views.ADDDoc, name='adddoc'),
   path('documentedu', views.documentedu, name='documentedu'),
   path('appro', views.appro, name='appro'),
     path('edit', views.Edit, name='edit'),
     path('deletedoc', views.Deletedoc),

     path('updatedoc/<str:id>', views.Updatedoc, name='updatedoc'),
     path('delete/<str:id>', views.Delete, name='delete'),
          path('deletedoc/<str:id>', views.Deletedoc, name='deletedoc'),
     path('update/<str:id>', views.Update, name='update'),
     re_path(r'^download/(?P<path>.*)$',serve,{  'document_root':settings.MEDIA_ROOT}),
path('searchappro', views.searchappro, name='searchappro'),
     path('delete/<str:id>', views.Delete),
    path('etudiant', etudiant, name="etudiant"),
   

    

]
if settings.DEBUG:
    urlpatterns+=static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)