from django import forms
from .models import Category, GestionDocument

class CategoryCreate(forms.ModelForm):
    
    class Meta:
        model = Category
        fields = '__all__'
        
class GestionDocumentCreate(forms.ModelForm):
    
    class Meta:
        model = GestionDocument
        fields = '__all__'
       