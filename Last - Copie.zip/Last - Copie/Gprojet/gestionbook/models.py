from django.db import models


class Category(models.Model):
    idCategory = models.CharField(max_length=50)
    nom  = models.CharField(max_length=50)
    dateCat = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return self.idCategory
    
class GestionDocument(models.Model):
    
    idBook= models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    author = models.CharField(max_length=50)
    description= models.TextField(max_length=500)
    dernier = models.CharField(max_length=50)
    doc = models.FileField(upload_to='media',blank=True, null=True)
    sujet  = models.CharField(max_length = 30)
    date = models.DateField(auto_now_add=True)
    
      
    def __str__(self):
        return self.idBook
    

