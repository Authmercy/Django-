import os
from django.conf import settings
from django.shortcuts import render
from django.shortcuts import render, redirect
from http.client import HTTPResponse
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from .models import Category
from .models import GestionDocument
from .forms import CategoryCreate
from django.http import Http404, HttpResponse
from django.db.models import Q
from django.shortcuts import get_object_or_404

# Create your 
# Create your views here.

def index(request):
      shelf = Category.objects.all()
      context = {
          'shelf':shelf,
      }
      return render(request, 'category.html', context)
def document(request):
      shelf = GestionDocument.objects.all()

      context = {
          'shelf':shelf,
      }
      return render(request, 'document.html', context)

def documentedu(request):
      shelf = GestionDocument.objects.all()

      context = {
          'shelf':shelf,
      }
      return render(request, 'documentedu.html', context)


def author(request):
      shelf = GestionDocument.objects.all()

      context = {
          'shelf':shelf,
      }
      return render(request, 'author.html', context)
def home(request):
      
      return render(request, 'home.html',)
def appro(request):
      
      return render(request, 'appro.html',)
def etudiant(request):
        shelf = Category.objects.all()

        context = {
          'shelf':shelf,
      }
        return render(request, 'etudiant.html', context)
def disconnect(request):
    pass

def download(request,path):
    file_path = os.path.join(settings.MEDIA_ROOT,path)
    if os.path.exists(file_path):
         with open(file_path,'rb')as fh:
           response = HttpResponse(fh.read(),content_type="application/doc")
           response['Content-Disposition'] = 'attachment; filename='+os.path.basename(file_path)
           return response
    raise Http404


def ADD(request):
    
    if request.method == 'POST':
        nom = request.POST.get('nom')
        
        dateCat = request.POST.get('dateCat')
        
        idCategory = request.POST.get('idCategory')
       
        shelf =Category(
               nom=nom,
              
               dateCat= dateCat,
              
               idCategory=idCategory
        )
        shelf.save()
    return redirect('index')          

    
def Edit(request):
    shelf = Category.objects.all()

    context = {
          'shelf':shelf,
      }
    return redirect(request, 'category.html', context)


def Update(request,id):
     if request.method == 'POST':
        nom = request.POST.get('nom')
        
        dateCat = request.POST.get('dateCat')
        
        idCategory = request.POST.get('idCategory')
       
        shelf = Category(
               nom=nom,
               id=id,
               dateCat= dateCat,
              
               idCategory=idCategory
        )
        shelf.save()
        return redirect('index')          


def Delete(request,id):
    id = int(id)
    shelf =Category.objects.get(id = id)
    shelf.delete()
    context = {
          'shelf':shelf,
      }
    return redirect('index')   


def download(request,path):
    file_path = os.path.join(settings.MEDIA_ROOT,path)
    if os.path.exists(file_path):
         with open(file_path,'rb')as fh:
           response = HttpResponse(fh.read(),content_type="application/doc")
           response['Content-Disposition'] = 'attachment; filename='+os.path.basename(file_path)
           return response
    raise Http404




def ADDDoc(request):
    
    if request.method == 'POST':
        name = request.POST.get('name')
        sujet = request.POST.get('sujet')
        author  = request.POST.get('author')
        description = request.POST.get('description')
        dernier  = request.POST.get('dernier')
        date = request.POST.get('date')
        doc = request.POST.get('doc')
        idBook = request.POST.get('idBook')
       
        shelf = GestionDocument(
               name=name,
               sujet=sujet,
               dernier=dernier,
               description=description,
               author=author,
               date= date,
               doc= doc,
               idBook =idBook
        )
        shelf.save()
    return redirect('document')          

    


def Updatedoc(request,id):
    if request.method == 'POST':
        name = request.POST.get('name')
        sujet = request.POST.get('sujet')
        author  = request.POST.get('author')
        description = request.POST.get('description')
        dernier  = request.POST.get('dernier')
        date = request.POST.get('date')
        doc = request.POST.get('doc')
        idBook = request.POST.get('idBook')
       
        shelf = GestionDocument(
               name=name,
               sujet=sujet,
               dernier=dernier,
               description=description,
               author=author,
               date= date,
               doc= doc,
               idBook =idBook
        )
        shelf.save()
        return redirect('document')          

def Deletedoc(request,id):
    id = int(id)
    shelf = GestionDocument.objects.get(id = id)
    shelf.delete()
    context = {
          'shelf':shelf,
      }
    return redirect('document')   



def search(request):
    
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        books = GestionDocument.objects.filter(name__icontains=q)
        return render(request, 'search.html', {'books': books, 'query': q})
    else:
        return render(request, 'search.html')
def searchadmin(request):
    
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        books = GestionDocument.objects.filter(author__icontains=q)
        return render(request, 'search.html', {'books': books, 'query': q})
    else:
        return render(request, 'search.html')    
def searchcat(request):
    
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        books = Category.objects.filter(nom__icontains=q)
        return render(request, 'searchcat.html', {'books': books, 'query': q})
    else:
        return render(request, 'searchcat.html')    
     
  
def searchappro(request):
    
    query = request.GET.get('q')
    sujet = request.GET.get('sujet')
    auteur = request.GET.get('auteur')
    dernier = request.GET.get('dernier')
    date = request.GET.get('date')

    # Filtrer les documents en fonction des critères de recherche
    documents = GestionDocument.objects.all()
    if query:
        documents = documents.filter(Q(name__icontains=query) | Q(description__icontains=query))
    if sujet:
        documents = documents.filter(sujet=sujet)
    if date:
        documents = documents.filter(date=date)    
    if auteur:
        documents = documents.filter(author=auteur)
    if dernier:
        documents = documents.filter(dernier=dernier)
        
    return render(request, 'searchappro.html', {'documents': documents})
      
  